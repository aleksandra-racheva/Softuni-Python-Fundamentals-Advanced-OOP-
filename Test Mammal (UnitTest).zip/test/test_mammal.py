from unittest import TestCase, main

from project.mammal import Mammal #CLEAN UP


class TestMammal(TestCase):
    def setUp(self):
        self.mammal = Mammal('some name', 'some type', 'some sound')

    def test_correct_initialisation(self):
        self.assertEqual('some name', self.mammal.name)
        self.assertEqual('some type', self.mammal.type)
        self.assertEqual('some sound', self.mammal.sound)

    def test_make_sound_method(self):
        make_sound = self.mammal.make_sound()
        self.assertEqual('some name makes some sound', make_sound)

    def test_get_kingdom_method(self):
        get_kingdom = self.mammal.get_kingdom()
        self.assertEqual('animals', get_kingdom)

    def test_info_method(self):
        info = self.mammal.info()
        self.assertEqual("some name is of type some type", info)


if __name__ == '__main__':
    main()