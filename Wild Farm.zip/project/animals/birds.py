from project.food import Meat, Vegetable, Fruit, Seed
from project.animals.animal import Bird


class Owl(Bird):
    @property
    def food_that_eats(self) -> list:
        return [Meat]

    @property
    def gained_weight(self):
        return 0.25

    def make_sound(self):
        return 'Hoot Hoot'


class Hen(Bird):
    @property
    def food_that_eats(self) -> list:
        return [Vegetable, Fruit, Seed, Meat]

    @property
    def gained_weight(self):
        return 0.35

    def make_sound(self):
        return 'Cluck'
