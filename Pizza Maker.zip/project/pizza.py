from project.dough import Dough
from project.topping import Topping


class Pizza:
    def __init__(self, name: str, dough: Dough, max_number_of_toppings: int) -> None:
        self.name = name
        self.dough = dough
        self.max_number_of_toppings = max_number_of_toppings
        self.toppings = {}


    @property
    def name(self) -> str:
        return self.__name

    @name.setter
    def name(self, value) -> None:
        if value != '':
            self.__name = value
        else:
            raise ValueError("The name cannot be an empty string")

    @property
    def dough(self) -> Dough:
        return self.__dough

    @dough.setter
    def dough(self, value: Dough):
        if value is not None:
            self.__dough = value
        else:
            raise ValueError("You should add dough to the pizza")


    @property
    def max_number_of_toppings(self) -> int:
        return self.__max_number_of_toppings

    @max_number_of_toppings.setter
    def max_number_of_toppings(self, value) -> None:
        if value > 0:
            self.__max_number_of_toppings = value
        else:
            raise ValueError("The maximum number of toppings cannot be less or equal to zero")

    def add_topping(self, topping: Topping):
        if self.max_number_of_toppings <= len(self.toppings):
            raise ValueError("Not enough space for another topping")
        if topping.topping_type not in self.toppings:
            self.toppings[topping.topping_type] = topping.weight
        else:
            self.toppings[topping.topping_type] += topping.weight

    def calculate_total_weight(self) -> float:
        return self.dough.weight + sum(self.toppings.values())

